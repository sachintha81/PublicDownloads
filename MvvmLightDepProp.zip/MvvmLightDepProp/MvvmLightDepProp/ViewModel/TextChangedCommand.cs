﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MvvmLightDepProp.ViewModel
{
    public class MainDisplayTextChanged : ICommand
    {
        protected readonly MainViewModel _owner;

        public MainDisplayTextChanged(MainViewModel owner)
        {
            _owner = owner;

            _owner.PropertyChanged += (s, e) =>
            {
                CanExecuteChanged?.Invoke(this, EventArgs.Empty);
            };
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            _owner.MainTextChanged();
        }
    }

    public class UCDisplayTextChanged : ICommand
    {
        protected readonly MainViewModel _owner;

        public UCDisplayTextChanged(MainViewModel owner)
        {
            _owner = owner;

            _owner.PropertyChanged += (s, e) =>
            {
                CanExecuteChanged?.Invoke(this, EventArgs.Empty);
            };
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            _owner.UCTextChanged();
        }
    }
}
