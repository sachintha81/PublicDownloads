﻿using GalaSoft.MvvmLight;
using MvvmLightDepProp.Model;

namespace MvvmLightDepProp.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public const string MainDisplayPropertyName = "MainDisplay";

        private string _mainDisplay = string.Empty;

        public string MainDisplay
        {
            get { return _mainDisplay; }
            set
            {
                if (_mainDisplay == value) { return; }
                _mainDisplay = value;
                RaisePropertyChanged(() => MainDisplay);
            }
        }

        public const string UCDisplayTextPropertyName = "UCDisplayText";

        private string _ucDisplayText = string.Empty;

        public string UCDisplayText
        {
            get { return _ucDisplayText; }
            set
            {
                if (_ucDisplayText == value) { return; }
                _ucDisplayText = value;
                RaisePropertyChanged(() => UCDisplayText);
            }
        }

        public MainDisplayTextChanged MainDisplayTextChangedCommand { get; private set; }
        public UCDisplayTextChanged UCDisplayTextChangedCommand { get; private set; }

        public MainViewModel(IDataService dataService)
        {
            MainDisplayTextChangedCommand = new MainDisplayTextChanged(this);
            UCDisplayTextChangedCommand = new UCDisplayTextChanged(this);
        }

        public void MainTextChanged()
        {
            UCDisplayText = MainDisplay;
        }

        public void UCTextChanged()
        {
            MainDisplay = UCDisplayText;
        }
    }
}