﻿using System.Windows;
using MvvmLightDepProp.ViewModel;

namespace MvvmLightDepProp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Closing += (s, e) => ViewModelLocator.Cleanup();
            TxtInput.Focus();
        }
    }
}