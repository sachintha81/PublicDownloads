﻿using System.Windows;
using System.Windows.Controls;

namespace MvvmLightDepProp
{
    /// <summary>
    /// Interaction logic for TextDisplay.xaml
    /// </summary>
    public partial class TextDisplay : UserControl
    {
        public TextDisplay()
        {
            InitializeComponent();
        }

        public event RoutedEventHandler RoutedTextChanged;

        public static readonly DependencyProperty DisplayProperty = DependencyProperty.Register("Display", typeof(string), typeof(TextDisplay));
        public string Display
        {
            get { return (string)GetValue(DisplayProperty); }
            set
            {
                SetValue(DisplayProperty, value);
            }
        }

        private void TxtDisplay_TextChanged(object sender, TextChangedEventArgs e)
        {
            Display = TxtDisplay.Text;
            RoutedTextChanged?.Invoke(this, new RoutedEventArgs());
        }
    }
}
