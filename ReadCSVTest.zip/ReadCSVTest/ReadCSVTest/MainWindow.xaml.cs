﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReadCSVTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<CSVPerson> People { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                var file = @"Content\people.csv";
                var path = System.IO.Path.Combine(Directory.GetCurrentDirectory(), file);
                if (ReadPeopleList(path, out List<CSVPerson> people, out string msg))
                {
                    People = people.ToList();
                }
                DataContext = this;
            }
            catch (Exception ex)
            {
                var log = "Log.log";
                var error = "==============================================================" + Environment.NewLine;
                error += ex.Message + Environment.NewLine;
                error += ex.StackTrace + Environment.NewLine;
                error += "==============================================================" + Environment.NewLine;
                File.WriteAllText(log, error);
            }
        }

        public static bool ReadPeopleList(string path, out List<CSVPerson> people, out string msg)
        {
            bool ret = true;
            msg = string.Empty;
            people = null;

            try
            {
                using (var reader = new StreamReader(path))
                {
                    using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                    {
                        people = csv.GetRecords<CSVPerson>().ToList();
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                msg = ex.Message;
                ret = false;
            }

            return ret;
        }

    }

    public class CSVPerson
    {
        public string Name { get; set; }
    }
}
