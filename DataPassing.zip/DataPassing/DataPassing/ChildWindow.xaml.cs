﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataPassing
{
    /// <summary>
    /// Interaction logic for ChildWindow.xaml
    /// </summary>
    public partial class ChildWindow : Window
    {
        public DataTransferDelegate dataTransferDelegate;

        public ChildWindow(DataTransferDelegate del)
        {
            InitializeComponent();

            dataTransferDelegate = del;

            InitCombo();
        }

        private void InitCombo()
        {
            CmbItems.Items.Add("Arthur Dent");
            CmbItems.Items.Add("Tricia McMillan");
            CmbItems.Items.Add("Ford Prefect");
            CmbItems.Items.Add("Zaphod Beeblebrox");
            CmbItems.SelectedIndex = 0;
        }

        private void CmbItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dataTransferDelegate?.Invoke(CmbItems.SelectedItem.ToString());
        }
    }
}
